// SECURITYSTUDIO.h : main header file for the SECURITYSTUDIO application
//

#if !defined(AFX_SECURITYSTUDIO_H__68256967_08C6_4B81_95EB_249E343C6B5A__INCLUDED_)
#define AFX_SECURITYSTUDIO_H__68256967_08C6_4B81_95EB_249E343C6B5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// APPLICATION:
// See SECURITYSTUDIO.cpp for the implementation of this class
//

class APPLICATION : public CWinApp
{
public:
	APPLICATION();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(APPLICATION)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(APPLICATION)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SECURITYSTUDIO_H__68256967_08C6_4B81_95EB_249E343C6B5A__INCLUDED_)
