// SECURITYSTUDIODlg.cpp : implementation file
//

#include "stdafx.h"
#include "SECURITYSTUDIO.h"
#include "SECURITYSTUDIODlg.h"

# include <tlhelp32.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

# define Tabs 2
# define TabTitles {"PROCESS","ABOUT"}



/////////////////////////////////////////////////////////////////////////////
// DIALOG dialog


DIALOG::DIALOG(CWnd* pParent /*=NULL*/)
	: CDialog(DIALOG::IDD, pParent)
{
	//{{AFX_DATA_INIT(DIALOG)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	
}

void DIALOG::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DIALOG)
	DDX_Control(pDX, IDC_TAB, m_tab);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(DIALOG, CDialog)
	//{{AFX_MSG_MAP(DIALOG)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB, OnSelchangeTab)
	ON_COMMAND(ID_ABOUT_MICROCORE, OnAboutMicrocore)
	ON_COMMAND(MENU_KILL, OnKill)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DIALOG message handlers

BOOL DIALOG::OnInitDialog()
{
	CDialog::OnInitDialog();
	CMenu * menu = new CMenu;
	menu->LoadMenu(IDR_MENU);
	this->SetMenu(menu);
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog


	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	char* var1[Tabs] = TabTitles;// My Style
	for (int i = 0 ; i < Tabs; i++)
	{
		m_tab.InsertItem(i,var1[i]);
	}
	mPAGE1.Create(IDD_PAGE1,GetDlgItem(IDC_TAB));
	mABOUT.Create(IDD_ABOUT,GetDlgItem(IDC_TAB));

	NewTab();

//SetTimer(1,2000,NULL);
	// TODO: Add extra initialization here
	mPAGE1.NEWLIST();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.



void DIALOG::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR DIALOG::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}




void DIALOG::OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
NewTab();
	*pResult = 0;
}


void DIALOG::NewTab()
{
if(m_tab.GetCurSel()==0)
{
mABOUT.ShowWindow(false);
mPAGE1.ShowWindow(true);
}
else if(m_tab.GetCurSel() == 1)
{
mABOUT.ShowWindow(true);
mPAGE1.ShowWindow(false);
}
}

void DIALOG::OnAboutMicrocore() 
{
m_tab.SetCurSel(1);
NewTab();	
}

/*void DIALOG::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent==1)
	{
	PROCESSENTRY32 pe32;
pe32.dwSize = sizeof(pe32); 
HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
BOOL bMore = ::Process32First(hProcessSnap, &pe32); 

	while(bMore)
	{
	
	mPAGE1.m_list.InsertString(mPAGE1.m_list.GetCount(),(LPCTSTR)_T(pe32.szExeFile));
	bMore=::Process32First(hProcessSnap,&pe32);
	
	}
	::CloseHandle(hProcessSnap);
	}
	CDialog::OnTimer(nIDEvent);
}
*/
/*
void DIALOG::OnTimer(UINT nIDEvent) 
{
	mPAGE1.NEWLIST();
	
	CDialog::OnTimer(nIDEvent);
}
*/


void DIALOG::OnKill() 
{
mPAGE1.killprocess();	
}
