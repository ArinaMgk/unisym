// PAGE1.cpp : implementation file
//

#include "stdafx.h"
#include "SECURITYSTUDIO.h"
#include "PAGE1.h"
# include <tlhelp32.h>
# include <windows.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPAGE1 dialog

CPAGE1::CPAGE1(CWnd* pParent /*=NULL*/)
	: CDialog(CPAGE1::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPAGE1)
	//}}AFX_DATA_INIT
		 


	
}


void CPAGE1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPAGE1)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPAGE1, CDialog)
	//{{AFX_MSG_MAP(CPAGE1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPAGE1 message handlers



void CPAGE1::OnButton2() 
{
	NEWLIST();
	
}

void CPAGE1::NEWLIST()
{
m_list.ResetContent();
PROCESSENTRY32 pe32;
pe32.dwSize = sizeof(pe32); 
HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
BOOL bMore = ::Process32First(hProcessSnap, &pe32); 
if(hProcessSnap==INVALID_HANDLE_VALUE)
{
return;
}
	while(bMore)
	{
	
	m_list.InsertString(m_list.GetCount(),(LPCTSTR)_T(pe32.szExeFile));
	bMore=::Process32Next(hProcessSnap,&pe32);
	
	}
	::CloseHandle(hProcessSnap);
}

void CPAGE1::OnButton1() 
{
	killprocess();
	
}

void CPAGE1::killprocess()
{
CString  var2;
m_list.GetText(m_list.GetCurSel(),var2);
//WinExec("cmd.exe /c taskkill /F /IM "+var2+" /t",SW_SHOW);
system("taskkill /F /IM "+var2+" /t");
NEWLIST();
}
