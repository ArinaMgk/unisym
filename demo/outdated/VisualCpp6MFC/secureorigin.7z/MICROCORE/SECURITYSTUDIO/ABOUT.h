#if !defined(AFX_ABOUT_H__F04226B5_7C3A_4598_8D49_DE8D57877946__INCLUDED_)
#define AFX_ABOUT_H__F04226B5_7C3A_4598_8D49_DE8D57877946__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ABOUT.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CABOUT dialog

class CABOUT : public CDialog
{
// Construction
public:
	CABOUT(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CABOUT)
	enum { IDD = IDD_ABOUT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CABOUT)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CABOUT)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ABOUT_H__F04226B5_7C3A_4598_8D49_DE8D57877946__INCLUDED_)
